/**
 * MySubmarine
 * @constructor
 */
 function MySubmarine(scene, minS, maxS, minT, maxT)
 {
 	CGFobject.call(this,scene);

	this.triangle = new MyTriangle(scene, minS, maxS, minT, maxT);
	this.rotation = 0;
	this.x_position = 0;
	this.z_position = 0;

 	this.initBuffers();
 }

MySubmarine.prototype = Object.create(CGFobject.prototype);
MySubmarine.prototype.constructor = MySubmarine;

MySubmarine.prototype.rotate = function(val)
{
	this.rotation += val * Math.PI / 180.0;
};

MySubmarine.prototype.move = function(val)
{
	this.x_position += val * Math.cos(this.rotation - Math.PI / 2.0);
	this.z_position += val * Math.sin(this.rotation + Math.PI / 2.0);
	/*if (this.x_position < -this.scene.plane_size)
	{
		this.x_position = -this.scene.plane_size;
	}
	else if (this.x_position > this.scene.plane_size)
	{
		this.x_position = this.scene.plane_size;
	}

	if (this.z_position < -this.scene.plane_size)
	{
		this.z_position = -this.scene.plane_size;
	}
	else if (this.z_position > this.scene.plane_size)
	{
		this.z_position = this.scene.plane_size;
	}
	console.log(this.x_position);
	console.log(this.z_position);*/
};

MySubmarine.prototype.initBuffers = function() {
 	this.vertices = [
	 	0.5, 0.3, 0,
	 	-0.5, 0.3, 0,
	 	0, 0.3, 2
 	];

 	this.indices = [
 		0, 1, 2
 	];

 	this.normals = [
 		0,0,1,
 		0,0,1,
 		0,0,1
 	];

 	this.texCoords = [
 		this.minS, this.maxT,
		this.maxS, this.maxT,
		this.minS, this.minT,
		this.maxS, this.minT
  	];


 	this.primitiveType = this.scene.gl.TRIANGLES;
 	this.initGLBuffers();
};

MySubmarine.prototype.display = function()
{
	this.scene.pushMatrix();
		this.scene.translate(this.x_position, 0, this.z_position);
		this.scene.rotate(this.rotation, 0, 1, 0);
		this.triangle.display();
	this.scene.popMatrix();
}